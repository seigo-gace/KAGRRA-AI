# KAGRRA COMPLETE DEV PACKAGE v3 VERIFIED

KAGRRA is a Claude-like Gemini API runtime enclosed inside a V8 workspace boundary.

This package is generated as a single integrated project, not a split add-on pack.

## Included Runtime Layers

- Gemini API client with dry-run mode
- SONNET / OPUS / MYTHOS / HAIKU dense persona definitions
- Deterministic router
- Skill manifest
- Executable skill registry
- Documentation skills
- Research skills
- MYTHOS 16-lane analysis skills
- HAIKU atomic execution skills
- Security policy
- Tool runtime
- Evidence ledger
- Runtime state machine
- Shadow workspace
- Recovery engine
- V8 workspace adapter
- Dashboard server
- Tests and audit scripts
- Container files
- CI workflow
- ClaudeData-compatible operation document

## Setup

```bash
cp .env.example .env
npm test
npm run audit
```

No npm install is required for the default runtime because this package uses Node.js built-in modules only.

## Dry Run

```bash
npm run doctor
node src/cli.js route "unknown V8 crash"
node src/cli.js run "unknown V8 crash"
```

## Live Gemini API

Edit `.env` or export variables:

```bash
export GEMINI_API_KEY="YOUR_KEY"
export KAGRRA_DRY_RUN=false
node src/cli.js run "Analyze V8 build failure"
```

## Dashboard

```bash
node src/cli.js dashboard
```

Open:

```text
http://localhost:8787
```

## V8 Workspace

Place or mount V8 under:

```text
workspaces/v8
```

The runtime will still boot in dry-run mode without a V8 checkout.
